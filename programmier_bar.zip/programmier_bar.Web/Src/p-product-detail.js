// import 'bootstrap/dist/js/bootstrap.bundle';
// import 'bootstrap/dist/js/bootstrap.bundle';
// import './../bootstrap/dist/js/bootstrap.bundle';
// import 'bootstrap/dist/js/bootstrap';
import './../node_modules/bootstrap/dist/js/bootstrap.bundle';

import dStock from './components/dialogues/d-stock';
import PageHTML from './p-product-detail.html';
import cTreeview from './components/category-treeview/c-treeview';

export default class pProductDetail {
  //================================================================================================
  #args = null;
  #cTreeview = null;
  // #networkDataReceived = false;


  //================================================================================================
  constructor(args) {
    this.#args = args;
    args.target.innerHTML = PageHTML;
    //-----------------------------------------
    const textCharcode = args.target.querySelector('#textCharcode');
    const textName = args.target.querySelector('#textName');
    const buttonSave = args.target.querySelector('#buttonSave');
    const alertMessage = args.target.querySelector('#alertMessage');
    const accordionItem2 = args.target.querySelector('#accordionItem2');
    const accordionItem3 = args.target.querySelector('#accordionItem3');
    //----------
    // Stock
    const collapseTwo = args.target.querySelector('#collapseTwo');
    const buttonStockPlus = args.target.querySelector('#buttonStockPlus');
    const buttonStockMinus = args.target.querySelector('#buttonStockMinus');
    //----------
    // Filedata
    const collapseThree = args.target.querySelector('#collapseThree');
    const rowFiledata = args.target.querySelector('#rowFiledata');
    const fileFiledata = args.target.querySelector('#fileFiledata');
    // const containerDatei = args.target.querySelector('#containerFiledata');

    let product = null;

    const dialogueStock = new dStock({
      target: args.target,
      app: args.app,
      saveClick: () => {
        this.#stockListRead(product.productUid);
      }
    });
    
    buttonStockPlus.addEventListener('click', () => {
    if (!product || !product.productId) {
        // build product object from form...
        product = {
          productId: null,
          productUid: Date.now().toString(),
          charcode: textCharcode.value,
          name: textName.value,
          productCategoryList: this.#cTreeview.selCats.map(c=>({
            productId: null, categoryId: c.categoryId
          }))
        };
        // save it
        args.app.apiSet(r => {
          product = r.product;                 // now has productId
          // now open Stock dialog
          dialogueStock.show({ product, modus: 'p' });
        }, ex => alert(ex), '/product', null, product);
      } else {
        // already saved
        dialogueStock.show({ product, modus: 'p' });
      }
    });

    buttonStockMinus.addEventListener('click', () => {
    if (!product || !product.productId) {
        // build product object from form...
        product = {
          productId: null,
          productUid: Date.now().toString(),
          charcode: textCharcode.value,
          name: textName.value,
          productCategoryList: this.#cTreeview.selCats.map(c=>({
            productId: null, categoryId: c.categoryId
          }))
        };
        // save it
        args.app.apiSet(r => {
          product = r.product;                 // now has productId
          // now open Stock dialog
          dialogueStock.show({ product, modus: 'n' });
        }, ex => alert(ex), '/product', null, product);
      } else {
        // already saved
        dialogueStock.show({ product, modus: 'n' });
      }
    });

    const colCategoryTreeview = args.target.querySelector('#colCategoryTreeview');

    this.#cTreeview = new cTreeview({
      target: colCategoryTreeview,
      app: args.app,
      multiSelect: true,
    });

    //-----------------------------------------
    // events
    //-----------------------------------------
    buttonSave.addEventListener( 'click', () => {

      alertMessage.classList.remove('alert-success', 'alert-danger');
      alertMessage.classList.add('d-none');

      if (!product) {
        product = {
          productId: null,
          productUid: null
        };
      }

      product.charcode = textCharcode.value ? textCharcode.value : null;
      product.name = textName.value ? textName.value : null;

      if (this.#cTreeview.selCats && this.#cTreeview.selCats.length > 0) {
        product.productCategoryList = [];
        for (const selCats of this.#cTreeview.selCats) {
          product.productCategoryList.push({
            productId: product.productId,
            categoryId: selCats.categoryId
          });
        }
      }
      product.productUid = Date.now().toString();

      args.app.apiSet((r) => {
        alertMessage.innerText = r.message;
        if (r.success) {
          product = r.product;
          alert(r.message);
          window.open('#productdetail?id=' + r.product.productUid, '_self');

          setTimeout(() => {
            alertMessage.classList.add('d-none');
          }, 3000);
        }

      }, (ex) => {
          if('serviceWorker' in navigator && 'SyncManager' in window) {
            navigator.serviceWorker.ready
              .then(sw => {
                if (product.artikelId == null) 
                {
                  writeData('product-create', product)
                    .then(() => {
                      return sw.sync.register('sync-new-product');
                    })
                    .then(() => {
                      writeData('product-cache', product);
                    })
                    .catch(function(err) {
                      console.log(err);
                    }).finally(()=> {
                  });
                }
              else {
                  writeData('product-update', product)
                    .then(() => {
                      return sw.sync.register('sync-updated-product');
                    })
                    .then(() => {
                      deleteItemFromData('product-cache', product.productId);
                      writeData('product-cache', product);
                    })
                    .catch(function(err) {
                      console.log(err);
                    }).finally(()=> {
                  });
                }
              });
            }
        
        alertMessage.classList.add('alert-danger');
        alertMessage.classList.remove('d-none');
        alertMessage.innerText = ex;
      }, '/product', product.productId, product);
    });

    //-----------------------------------------
    // stock
    buttonStockPlus.addEventListener( 'click', () =>   {
      dialogueStock.show({
        product: product,
        modus: 'p'
      });
    });

    buttonStockMinus.addEventListener( 'click', () =>   {
      dialogueStock.show({
        product: product,
        modus: 'n'
      });
    });

    //-----------------------------------------
    // filedata
    rowFiledata.addEventListener( 'click', () => {
      fileFiledata.click();
    });

    rowFiledata.addEventListener( 'dragover', (e) => {
      e.stopPropagation();
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
    });  

    rowFiledata.addEventListener( 'drop', (e) => {
      e.stopPropagation();
      e.preventDefault();
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        args.app.apiDatei((r) => {
          console.log(r);
        }, (ex) => {  
          alert(ex);
        }, product, e.dataTransfer.files);
      }
    });

    fileFiledata.addEventListener( 'change', (e) => {
      //const imgBild = args.target.querySelector('#imgBild');
      // const reader = new FileReader();
      // reader.onload = (r) => {
      //   imgBild.src = r.target.result;
      // };
      // reader.readAsDataURL(fileDatei.files[0]);

      args.app.apiFiledata((r) => {
        console.log(r);
      }, (ex) => {  
        alert(ex);
      }, product, fileFiledata.files);
    });

    collapseTwo.addEventListener('shown.bs.collapse', (e) => {
      e.stopPropagation();
      this.#stockListRead(product.productid);
    });

    collapseThree.addEventListener( 'shown.bs.collapse', (e) => {
      e.stopPropagation();
      
      args.app.apiGet((r) => {

        let html = '<div class="row">';
        let idx = 0;
        for (const fd of r) {
          if (idx > 0 && idx % 3 == 0) {  
            html += '</div><div class="row mt-3">';
          }

          html += `
            <div class="col-12 col-lg-4 mt-3 mt-lg-0">
              <div class="card w-100">
                <img src="${fd.contentUrl}" class="card-img-top" alt="Foto" />
                <div class="card-body">
                  <h5 class="card-title">${fd.name}</h5>
                </div>
              </div>              
            </div>
          `;
          idx++;
        }
        html += '</div>';
        containerFiledata.innerHTML = html;
      }, (ex) => {
        alert(ex);
      }, '/product/' + product.productUid + '/filedata');
    });



    //-----------------------------------------
    // init
    //-----------------------------------------
    
    // let networkDataReceived = false;

    // if ('indexedDB' in window) {
    //   readItemFromData('product-cache', args.id)
    //     .then(data => {
    //       if (!networkDataReceived) { // If network data hasn't already updated the display
    //         console.log('selected article From cache', data);
    //         product = data;
    //         textCharcode.value = product.charcode;
    //         textName.value = product.name;
    //       }
    //     });
    // }

    args.app.apiGet((cl) => {
      // this.#networkDataReveived = false;
      this.#cTreeview.categoryList = cl;
      if (args.id) {
        args.app.apiGet((r) => {
          networkDataReceived = true;
          product = r;
          textCharcode.value = product.charcode;
          textName.value = product.name;

          if (product.productCategoryList && product.productCategoryList.length > 0) {
            const sc = [];
            let gfk = null;
            for (const prodc of product.productCategoryList) {
              gfk = cl.filter(c => c.categoryId == prodc.categoryId);
              if (gfk.length == 1) sc.push(gfk[0]);
            }
            this.#cTreeview.selCats = sc;
          }
        }, (ex) => {
          alert(ex);
        }, '/product/' + args.id); 
      } else {
        const co = new bootstrap.Collapse('#collapseOne');
        co.show();
        accordionItem2.classList.add('d-none');
        accordionItem3.classList.add('d-none');
      }
    }, (ex) => {
      alert(ex);
    }, '/category');

    //-----------------------------------------
    //-----------------------------------------
  } // constructor

  //================================================================================================
  // private
  //================================================================================================
  #stockListRead(id)  {

    const tableStock = this.#args.target.querySelector('#tableStock>tbody');
    const infoTextSum = this.#args.target.querySelector('#infoSum');

    this.#args.app.apiGet((r) => {

      let html = '';
      const dateFormat = new Intl.DateTimeFormat(navigator.language, {
        dateStyle: "medium",
        timeStyle: "short",
      });

      let ga = 0;

      for (const b of r) {
        ga += b.amount;
        html += `
          <tr>
            <td>${dateFormat.format(new Date(b.datetime))}</td>
            <td>${b.amount}</td>
            <td>${b.note}</td>
            <td>${b.personNameFull}</td>
          </tr>
        `;
      }
      tableStock.innerHTML = html;
      infoTextSum.innerText = ga;
    }, (ex) => {
      alert(ex);
    }, '/product/' + id + '/stock');
  }
  //================================================================================================
  //================================================================================================
} // class