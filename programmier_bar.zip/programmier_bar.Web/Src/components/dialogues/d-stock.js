import bootstrap from './../../../node_modules/bootstrap/dist/js/bootstrap.bundle';
// import 'bootstrap/dist/js/bootstrap.bundle';

import ComponentHTML from './d-stock.html';

export default class dStock {
  //==========================================================================================================
  // private vars
  #args = null;
  #modal = null;
  #stock = null;
  #product = null;
  #modus = null;

  //==========================================================================================================
  constructor(args) {
    this.#args = args;
    args.target.insertAdjacentHTML('beforeend', ComponentHTML);

    const modalStock = args.target.querySelector('#modalStock');
    this.#modal = new bootstrap.Modal(modalStock);

    const numberAmount = this.#args.target.querySelector('#numberAmountModalStock');
    const textNote = this.#args.target.querySelector('#textNoteModalStock');
    const buttonSave = this.#args.target.querySelector('#buttonSaveModalStock');

    //----------------------------------------------------
    buttonSave.addEventListener( 'click', () => {

      if (!this.#stock) {
        this.#stock = {
          stockId: null,
          productId: this.#product.productId
        };
      }

      if (numberAmount.value) {
        if (this.#modus == 'p') this.#stock.amount = parseInt(numberAmount.value);
        else this.#stock.amount = -1 * parseInt(numberAmount.value);
      } else {
        this.#stock.amount = 0;
      }
       
      this.#stock.note = textNote.value ? textNote.value : null;

      args.app.apiSet((r) => {
        if (r.success) {
          if (args.saveClick && typeof args.saveClick === 'function') args.saveClick();
          this.#modal.hide();
        }
      }, (ex) => {
        alert(ex);
      }, '/stock', this.#stock.stockId, this.#stock);
    });
  }
  //==========================================================================================================
  show(args) {

    if (args) {
      if (args.product) this.#product = args.product;
      if (args.modus) this.#modus = args.modus;
    }
    this.#modal.show();
  }
} // class