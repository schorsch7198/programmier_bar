import './../node_modules/bootstrap/dist/css/bootstrap.css';
import './../node_modules/bootstrap-icons/font/bootstrap-icons.css';
import './css/app.css';

import Application from "./app.js";

new Application();