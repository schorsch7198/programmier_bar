﻿using Microsoft.AspNetCore.Mvc;
using programmier_bar.dbClassLibrary;

namespace programmier_bar.DataApiControllers.Controllers
{
	// Controller for handling page initialization, logout, and fetching initial product/category data
	[Route("[controller]")]
	[ApiController]
	public class PageController : ControllerBase
	{
		// GET /Page/init – FETCH CURRENT USER
		[HttpGet("init")]
		public IActionResult PageInit()
		{
			IActionResult result = null;
			try
			{
				Person user = Person.Get(this);
				if (user == null) result = Unauthorized();
				else result = Ok(user);
			}
			catch (Exception ex)
			{
#if DEBUG
				result = StatusCode(500, new { message = ex.Message });
#else
				result = StatusCode(500);
#endif
			}
			return result;
		}


		// GET /Page/productlist – FETCH ALL PRODUCTS AND CATEGORIES for page initialization
		[HttpGet("productlist")]
		public IActionResult PageProductList()
		{
			IActionResult result = null;
			try
			{
				List<Product> productList = Product.GetList();
				List<Category> categoryList = Category.GetList();
				result = Ok(new
				{
					productList,
					categoryList
				});
			}
			catch (Exception ex)
			{
			#if DEBUG
				result = StatusCode(500, new { message = ex.InnerException != null ? ex.InnerException.Message : ex.Message });
			#else
				result = StatusCode(500, new { message = ex.ToString() });
			#endif
			}
			return result;
		}


		// GET /Page/logout – DELETE LOGIN_TOKEN, delete cookie and expire session
		[HttpGet("logout")]
		public IActionResult PageLogout()
		{
			IActionResult result = null;
			try
			{
				Person user = Person.Get(this);
				user.LoginUntil = null;
				user.LoginToken = null;
				user.Save();
				Response.Cookies.Delete("logintoken");
				result = Ok(new { success = true, message = "Logout successfull!" });
			}
			catch (Exception ex)
			{
#if DEBUG
				result = StatusCode(500, new { message = ex.Message });
#else
				result = StatusCode(500);
#endif
			}
			return result;
		}
	}
}